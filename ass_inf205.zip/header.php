<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Trang chủ</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<style type="text/css">
		.mytable {
			text-align: center;
		}
	</style>
</head>

<body>

<div class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php" title='Programming Blog'>Khách hàng</a>
	        <a class="navbar-brand" href="#">Loại sản phẩm</a>
            <a class="navbar-brand" href="products.php">Sản phẩm</a>
            <a class="navbar-brand" href="#">Hóa đơn</a>
            <a class="navbar-brand" href="#">Chi tiết hóa đơn</a>
        </div>
    </div>
</div>